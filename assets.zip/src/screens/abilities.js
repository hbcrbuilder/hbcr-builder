export function AbilitiesScreen() {
  return `
    <div class="screen origin-panel">
      <div class="h1">Abilities</div>
      <div class="h2">Allocate ability scores (placeholder)</div>

      <div class="hint" style="margin-top:14px">
        This step will become the full ability + proficiency allocator. For now it's a placeholder screen.
      </div>

      <div class="bottom-nav">
        <button class="btn" data-action="back">Back</button>
      </div>
    </div>
  `;
}
